package com.example.currencyconvertorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner sp1,sp2;
    EditText ed1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1=findViewById(R.id.txtAmount);

        sp1=findViewById(R.id.spfrom);
        sp2=findViewById(R.id.spTo);
        b1=findViewById(R.id.btn1);


        String [] from={"USD"};
        ArrayAdapter adapter= new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,from);
        sp1.setAdapter(adapter);


        String [] to={"Bangladeshi TK","Indian Rupes","Pakistani Rupes","Srinkan Rupes"};
        ArrayAdapter adapter1= new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,to);
        sp2.setAdapter(adapter1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double tot;
                Double amount= Double.parseDouble(ed1.getText().toString());
                if (sp1.getSelectedItem().toString()=="USD" && sp2.getSelectedItem().toString()=="Bangladeshi TK"){
                    tot=amount*88.00;
                   Toast.makeText(getApplicationContext(),tot.toString(),Toast.LENGTH_LONG).show();
                }
                if (sp1.getSelectedItem().toString()=="USD" && sp2.getSelectedItem().toString()=="Indian Rupes"){
                    tot=amount*70.00;
                    Toast.makeText(getApplicationContext(),tot.toString(),Toast.LENGTH_LONG).show();
                }
                if (sp1.getSelectedItem().toString()=="USD" && sp2.getSelectedItem().toString()=="Pakistani Rupes"){
                    tot=amount*95.00;
                    Toast.makeText(getApplicationContext(),tot.toString(),Toast.LENGTH_LONG).show();
                }
                if (sp1.getSelectedItem().toString()=="USD" && sp2.getSelectedItem().toString()=="Srinkan Rupes"){
                    tot=amount*180.00;
                    Toast.makeText(getApplicationContext(),tot.toString(),Toast.LENGTH_LONG).show();
                }


            }
        });
        
    }
}