package com.example.volleycheck;

public class MainData {
    //Initialize all variables

    private  String name , image;


    //generate gatter and setter

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
