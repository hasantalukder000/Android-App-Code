package com.example.volleycheck;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Initialize all variables
   ListView listView;
   ArrayList<MainData> dataArrayList= new ArrayList<MainData>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign Variable

        listView=findViewById(R.id.list_view);

        // Url
         String url= "https://picsum.photos/v2/list";

         //Initalize progress dialog

        ProgressDialog dialog= new ProgressDialog(this);


        //Set Message
        dialog.setMessage("Please Wait....");

        //set non cancelled
        dialog.setCancelable(true);

        //show progress dialog
        dialog.show();

        //Intalize  string request

        StringRequest reques = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                 //check codition
                if (response != null){
                    dialog.dismiss();



                    try {
                        //Intalize respone json array
                        JSONArray jsonArray=  new JSONArray(response);
                        parseArray(jsonArray);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
               //Display Toast
                Toast.makeText(getApplicationContext(),error.toString()
                ,Toast.LENGTH_SHORT).show();
            }
        });

        //Initalize request queue

        RequestQueue queue= Volley.newRequestQueue(this);
        //add request
        queue.add(reques);
    }

    private void parseArray(JSONArray jsonArray) {

        // use for loop
         for (int i = 0;i<jsonArray.length();i++){

             try {
                 //intitalize json object
                 JSONObject object= jsonArray.getJSONObject(i);
                 //intialize main data
                 MainData data=  new MainData();

                 //set name
                  data.setName(object.getString("author"));

                  //set image
                 data.setImage(object.getString("download_url"));
                //add data list in array list
                 dataArrayList.add(data);

             } catch (JSONException e) {
                 e.printStackTrace();
             }

             //set adapter
             listView.setAdapter(new BaseAdapter() {
                 @Override
                 public int getCount() {
                     return dataArrayList.size();
                 }

                 @Override
                 public Object getItem(int position) {
                     return null;
                 }

                 @Override
                 public long getItemId(int position) {
                     return 0;
                 }

                 @Override
                 public View getView(int position, View convertView, ViewGroup parent) {

                     //Intalize View
                     View view= getLayoutInflater().inflate(
                             R.layout.iteam_main,null
                     );

                     //Intalize main data
                     MainData data= dataArrayList.get(position);


                     //Initialze and design  variable

                     ImageView imageView= view.findViewById(R.id.image_View);
                     TextView textView= view.findViewById(R.id.TextView);

                     //setImage

                     Glide.with(getApplicationContext())
                             .load(data.getImage())
                             .diskCacheStrategy(DiskCacheStrategy.ALL)
                             .into(imageView);


                     //set name and text
                      textView.setText(data.getImage());





                     return view;
                 }
             });
         }
    }
}