package com.example.edittextapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    private EditText editText2,editText1;
    private Button addButton,subButton,mulButton,divButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1 = (EditText) findViewById(R.id.editText1Id);
        editText2=(EditText)findViewById(R.id.editText2Id);

        addButton=(Button)findViewById(R.id.addBtnId);
      subButton = (Button) findViewById(R.id.subBtnId);
        mulButton=(Button)findViewById(R.id.mulBtnId);
        divButton = (Button) findViewById(R.id.divBtnId);
        resultTextView=(TextView)findViewById(R.id.resultTextViewId);
        addButton.setOnClickListener(this);
        subButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        String number1= editText1.getText().toString();
        String number2= editText2.getText().toString();



        double num1= Double.parseDouble(number1);
        double num2= Double.parseDouble(number2);


        if (view.getId()==R.id.addBtnId){
            double sum= num1+num2;
            resultTextView.setText("Result :"+sum);
        }
       else if (view.getId()==R.id.subBtnId){
            double sum= num1-num2;
            resultTextView.setText("Result :"+sum);
        }


    }

    public void div(View view) {

        String number1= editText1.getText().toString();
        String number2= editText2.getText().toString();



        double num1= Double.parseDouble(number1);
        double num2= Double.parseDouble(number2);
        double div = num1/num2;
        resultTextView.setText("Result :"+div);

    }

    public void mul(View view) {
        String number1= editText1.getText().toString();
        String number2= editText2.getText().toString();



        double num1= Double.parseDouble(number1);
        double num2= Double.parseDouble(number2);
        double mul = num1*num2;
        resultTextView.setText("Result :"+mul);
    }
}